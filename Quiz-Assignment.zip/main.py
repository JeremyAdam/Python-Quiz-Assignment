# Python Quiz Assignment

# Score
score = 0

# Question One
answerOne = input("\nWhat is the colour of the sky? ").lower()
if (answerOne == "blue" or answerOne == "lightblue"):
  print("Correct!")
  score += 1
else:
  print("Incorrect")

# Question Two
answerTwo = input("\nWhat do you do when you approach a stop sign? ").lower()
if (answerTwo == "stop"):
  print("Correct!")
  score += 1
else:
  print("Incorrect")

# Question Three
answerThree = input("\nWhat is my name? ").lower()
if (answerThree == "jeremy"):
  print("Correct!")
  score += 1
else:
  print("Incorrect")

# Question Four
answerFour = input("\nWhat do you protect in chess? ").lower()
if (answerFour == "king"):
  print("Correct!")
  score += 1
else:
  print("Incorrect")

# Output Score
print("\nYour score is " + str(score) + "/4 (" + str(round(score / 4 * 100)) + "%).")

# Provide Feedback
if (score == 1):
  print("Yikes, you need to study.")
elif (score == 2):
  print("Ehh, you barely passed.")
elif (score == 3):
  print("Wow, good job")
elif (score == 4):
  print("Beautiful, look at that 100%")
